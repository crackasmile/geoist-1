"""
Plotting utilities.

Wrappers to facilitate common plotting tasks using powerful third-party
libraries.

* :mod:`~geoist.vis.giplt`: 2D plotting using matplotlib_

.. _matplotlib: http://matplotlib.org/

----

"""
