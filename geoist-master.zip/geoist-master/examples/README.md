# examples  
for beginner
