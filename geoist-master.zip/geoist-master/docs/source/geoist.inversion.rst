geoist.inversion package
========================

Module contents
---------------

.. automodule:: geoist.inversion
    :members:
    :undoc-members:
    :show-inheritance:
